package driver;

import java.util.Scanner;

import model.Department;
import model.Employee;
import service.CredentialService;

public class DriverClass {

	public static void main(String[] args) {
		Employee employee= new Employee("Sasidaran", "Anbu");
		System.out.println("Enter your Department");
		System.out.println("1. Technical\n2. Legal\n3. HR\n4. Management");
		Scanner sc=new Scanner(System.in);
		int choice=sc.nextInt();
		Department department=new Department();
		CredentialService service=new CredentialService();
		switch(choice) {
		case 1:
		department.setDeptName("technical");
		String Email= service.generateEmail(employee, department);
		String Password= service.generatePassword();
		service.showCredentials(Email, Password);
		break;
		case 2:
		department.setDeptName("Legal");
		String Email= service.generateEmail(employee, department);
		String Password= service.generatePassword();
		service.showCredentials(Email, Password);
		break;
		case 3:
		department.setDeptName("HR");
		String Email= service.generateEmail(employee, department);
		String Password= service.generatePassword();
		service.showCredentials(Email, Password);
		break;
		case 4:
		department.setDeptName("Managment");
		String Email= service.generateEmail(employee, department);
		String Password= service.generatePassword();
		service.showCredentials(Email, Password);		
		break;
		}
	}
}
